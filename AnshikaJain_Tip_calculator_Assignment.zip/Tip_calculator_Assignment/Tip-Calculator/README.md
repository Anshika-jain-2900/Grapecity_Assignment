# Tip-Calculator
 Practice project creating a Tip Calclator using Html, Css, & Js
